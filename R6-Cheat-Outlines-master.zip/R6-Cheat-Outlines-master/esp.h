#pragma once
#include "utils.h"
#include "memory.h"
#include "battleye.h"
#include "cfg.h"
#include "offsets.h"
#include "vars.h"

void GameCache()
{
	while (true)
	{
		GameVars::gamemanager = offsets::getGameManager();
		GameVars::entitylist = offsets::entityManager(offsets::getGameManager()).first;
		GameVars::entitycount = offsets::entityManager(offsets::getGameManager()).second;
		//GameVars::currentweapon = offsets::WeaponManager(GameVars::actor);
		Sleep(100);
	}
}

void LoopESP()
{
	while (CFG::b_Loop)
	{
		// check if game is running, if not kill program
		if (!Utilities::IsProcessRunning(memory.pid))
		{
			FakeEye::unloadBEService();
			Utilities::Kill();
		}

		if (GetAsyncKeyState(VK_F1) & 1)
			CFG::b_EspGlow = !CFG::b_EspGlow;

		//if (offsets::roundstate() == 2 || offsets::roundstate() == 3) { // check if entity is in game
		for (int i = 1; i < GameVars::entitycount; i++) { // loop through entitycount			
			GameVars::controller = memory.read<std::uint64_t>(offsets::entityManager(offsets::getGameManager()).first + (i * sizeof(std::uint64_t))); // get controller by entitylist
			if (!GameVars::controller) continue; // check pointer	
			GameVars::pawn = offsets::player::pawn(GameVars::controller); // get player pawn through controller
			if (!GameVars::pawn) continue; // check pointer
			GameVars::actor = offsets::player::actor(GameVars::pawn); // get actor through pawn
			if (!GameVars::actor) continue; // check point

			if (CFG::b_EspGlow)
				offsets::player::outlines(GameVars::actor); // write outlines to player
			if (!CFG::b_EspGlow)
				offsets::player::removeOutlines(GameVars::actor); // write remove outlines to player
		}
		//}
		Sleep(10);
	}
}

void Misc()
{
	float Recoil = 0.0001f;
	if (CFG::b_NoRecoil)
	{
		memory.write<uint32_t>(GameVars::currentweapon + 0x214, (*(uint32_t*)&Recoil) + 0xDA7AC245); //recoil 1 = 0.056
		memory.write<uint32_t>(GameVars::currentweapon + 0x210, (*(uint32_t*)&Recoil) + 0xDC6530B3); //recoil 2 = 0.056
	}

	float Spread = 0.0f;
	if (CFG::b_NoSpread)
	{
		memory.write<uint32_t>(GameVars::currentweapon + 0x40, *(uint32_t*)(&Spread));
	}
	Sleep(10);
}