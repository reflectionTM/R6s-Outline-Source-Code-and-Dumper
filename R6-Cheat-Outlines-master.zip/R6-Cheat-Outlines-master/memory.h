#pragma once
#pragma once
#include <Windows.h>
#include <TlHelp32.h>
#include <WinUser.h>
#include <Psapi.h>
#include <stdint.h>
#include <string>
#include "lazy.h"

class Memory
{
public:
    uint64_t base = 0x0;
    uint32_t pid = 0x0;

    inline bool intialize()
    {
        if (GetPid())
        {
            if (GetModuleBaseAddr())
            {
                /*uint64_t bypassbase = base + 0x6D29FB0;
                uint64_t bypassval = 0x312E345337597777;
                write(bypassbase, bypassval);
                it is dtc 
                no this is not a pasted qbbypass 
                All Credits to raintm,*/
                return true;
            }
        }
        return false;
    }

    inline uint32_t GetPid()
    {
        HWND hWnd = FindWindowA(NULL, "Rainbow Six");
        DWORD PID;
        GetWindowThreadProcessId(hWnd, &PID);
        pid = (uint32_t)PID;
        return pid;
    }

    inline uint64_t GetModuleBaseAddr()
    {
        HMODULE h_modules[1024];
        DWORD pcb_needed;

        handle = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);

        if (K32EnumProcessModules(handle, h_modules, sizeof(h_modules), &pcb_needed))
        {
            for (unsigned int i = 0; i < (pcb_needed / sizeof(HMODULE)); i++)
            {
                TCHAR module_name[MAX_PATH];
                if (GetModuleFileNameEx(handle, h_modules[i], module_name, sizeof(module_name) / sizeof(TCHAR)))
                {
                    std::string str_module_name = module_name;
                    if (str_module_name.find(name) != std::string::npos)
                    {
                        base = (uint64_t)h_modules[i];
                        return base;
                    }
                }
            }
        }

        return 0;
    }

    std::uintptr_t FindProcess(const std::string& name)
    {
        const auto snap = LI_FN(CreateToolhelp32Snapshot).safe()(TH32CS_SNAPPROCESS, 0);
        if (snap == INVALID_HANDLE_VALUE) {
            return 0;
        }

        PROCESSENTRY32 proc_entry{};
        proc_entry.dwSize = sizeof proc_entry;

        auto found_process = false;
        if (!!LI_FN(Process32First).safe()(snap, &proc_entry)) {
            do {
                if (name == proc_entry.szExeFile) {
                    found_process = true;
                    break;
                }
            } while (!!LI_FN(Process32Next).safe()(snap, &proc_entry));
        }

        LI_FN(CloseHandle).safe()(snap);
        return found_process
            ? proc_entry.th32ProcessID
            : 0;
    }

    template<typename T>
    T read(uint64_t address)
    {
        T buffer;
        ReadProcessMemory(handle, (LPCVOID)address, &buffer, sizeof(T), NULL);
        return buffer;
    }

    template <class T>
    void read_array(uint64_t address, T* array, size_t len)
    {
        ReadProcessMemory(handle, (void*)address, array, sizeof(T) * len, NULL);
    }

    template<typename T>
    void write(uint64_t address, T buffer)
    {
        WriteProcessMemory(handle, (LPVOID)address, &buffer, sizeof(buffer), NULL);
    }

private:
    HANDLE handle = 0x0;
    std::string name = "RainbowSix.exe";
};

inline Memory memory;