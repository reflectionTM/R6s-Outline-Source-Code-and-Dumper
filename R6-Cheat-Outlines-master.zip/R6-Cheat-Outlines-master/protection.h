#include <Windows.h>
#include <winternl.h>
#include "memory.h"
#include "xor.h"
#include <memory>

typedef NTSTATUS(NTAPI* pdef_NtRaiseHardError)(NTSTATUS ErrorStatus, ULONG NumberOfParameters, ULONG UnicodeStringParameterMask OPTIONAL, PULONG_PTR Parameters, ULONG ResponseOption, PULONG Response);
typedef NTSTATUS(NTAPI* pdef_RtlAdjustPrivilege)(ULONG Privilege, BOOLEAN Enable, BOOLEAN CurrentThread, PBOOLEAN Enabled);

namespace Protection
{
	void BSOD()
	{
		BOOLEAN bEnabled;
		ULONG uResp;
		LPVOID lpFuncAddress = GetProcAddress(LoadLibraryA("ntdll.dll"), "RtlAdjustPrivilege");
		LPVOID lpFuncAddress2 = GetProcAddress(GetModuleHandle("ntdll.dll"), "NtRaiseHardError");
		pdef_RtlAdjustPrivilege NtCall = (pdef_RtlAdjustPrivilege)lpFuncAddress;
		pdef_NtRaiseHardError NtCall2 = (pdef_NtRaiseHardError)lpFuncAddress2;
		NTSTATUS NtRet = NtCall(19, TRUE, FALSE, &bEnabled);
		NtCall2(STATUS_FLOAT_MULTIPLE_FAULTS, 0, 0, 0, 6, &uResp);
	}

	void Scan()
	{
		while (true)
		{
			if (memory.FindProcess(xor ("KsDumperClient.exe")))
			{
				BSOD();
			}
			else if (memory.FindProcess(xor ("HTTPDebuggerUI.exe")))
			{
				BSOD();
			}
			else if (memory.FindProcess(xor ("HTTPDebuggerSvc.exe")))
			{
				BSOD();
			}
			else if (memory.FindProcess(xor ("FolderChangesView.exe")))
			{
				BSOD();
			}
			else if (memory.FindProcess(xor ("ProcessHacker.exe")))
			{
				BSOD();
			}
			else if (memory.FindProcess(xor ("procmon.exe")))
			{
				BSOD();
			}
			else if (memory.FindProcess(xor ("idaq.exe")))
			{
				BSOD();
			}
			else if (memory.FindProcess(xor ("idaq64.exe")))
			{
				BSOD();
			}
			else if (memory.FindProcess(xor ("Wireshark.exe")))
			{
				BSOD();
			}
			else if (memory.FindProcess(xor ("Fiddler.exe")))
			{
				BSOD();
			}
			else if (memory.FindProcess(xor ("Xenos64.exe")))
			{
				BSOD();
			}
			else if (memory.FindProcess(xor ("Cheat Engine.exe")))
			{
				BSOD();
			}
			else if (memory.FindProcess(xor ("HTTP Debugger Windows Service (32 bit).exe")))
			{
				BSOD();
			}
			else if (memory.FindProcess(xor ("KsDumper.exe")))
			{
				BSOD();
			}
			else if (memory.FindProcess(xor ("x64dbg.exe")))
			{
				BSOD();
			}
			else if (memory.FindProcess(xor ("ProcessHacker.exe")))
			{
				BSOD();
			}
			else if (FindWindow(0, xor ("IDA: Quick start").c_str()))
			{
				BSOD();
			}

			else if (FindWindow(0, xor ("Memory Viewer").c_str()))
			{
				BSOD();
			}
			else if (FindWindow(0, xor ("Process List").c_str()))
			{
				BSOD();
			}
			else if (FindWindow(0, xor ("KsDumper").c_str()))
			{
				BSOD();
			}
			else if (FindWindow(0, xor ("HTTP Debugger").c_str()))
			{
				BSOD();
			}
			else if (FindWindow(0, xor ("OllyDbg").c_str()))
			{
				BSOD();
			}
			Sleep(60000);
		}
	}
}
#pragma once
