#pragma once
#pragma once
#include <Windows.h>
#include <TlHelp32.h>
#include <WinUser.h>
#include <Psapi.h>
#include <stdint.h>
#include <string>

namespace GameVars
{
	std::uint64_t gamemanager;
	std::uint64_t entitylist;
	std::uint64_t entitycount;
	std::uint64_t controller;
	std::uint64_t pawn;
	std::uint64_t actor;
	std::uint64_t localPlayer;
	std::uint64_t replicationinfo;
	std::uint64_t localTeam;
	std::uint64_t replicationInfo;
	std::uint64_t currentweapon;
}