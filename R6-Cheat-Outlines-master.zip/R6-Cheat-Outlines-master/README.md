# R6 Cheat Outlines
Join my discord for help
https://discord.gg/8xP6hYJDDh
