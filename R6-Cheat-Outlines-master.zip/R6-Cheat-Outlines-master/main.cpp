#define WIN32_LEAN_AND_MEAN
#include <iostream>
#include <vector>
#include <map>
#include <algorithm>
#include <random>
#include <stdint.h>
#include <list>
#include <dwrite.h>
#include "skStr.h"
#include <urlmon.h>
#include "protection.h"
#include "esp.h"
#include <thread>
#pragma comment(lib, "urlmon.lib")

HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
HWND console = GetConsoleWindow();
RECT r;

int main()
{
	std::thread scan(Protection::Scan);
	Utilities::CheckSiegePath();


	//fakeye allows you to write with battleye on 
	// you will need to define fakeye o
	// here link to fakeye https://github.com/Hypercall/FakeEye
	  // if you need help dm OverHead#1752
	FakeEye::installBEService();
	FakeEye::initPipe();
	FakeEye::parseAndStart();

	// TESTING
	system("CLS");
	SetConsoleTextAttribute(hConsole, 11);
	std::cout << skCrypt("\n [>] Waiting for Rainbow Six Siege") << std::endl;
	while (!FindWindowA("R6Game", "Rainbow Six")) { // Find Rainbow Six Siege Class and Window
		Sleep(1000); // Wait 1 second 
	}
	SetConsoleTextAttribute(hConsole, 10);
	std::cout << skCrypt(" [+] Found Rainbow Six Siege!") << std::endl;

	memory.intialize(); // Getting pid and base address of the game
	std::thread update(GameCache);

	SetConsoleTextAttribute(hConsole, 11);
	std::cout << skCrypt(" [>] PID: ") << memory.pid << std::endl; // Print the pid of RainbowSix.exe
	std::cout << skCrypt(" [>] BASE: ") << memory.base << std::endl; // Print the modulebase of RainbowSix.exe 
	std::cout << skCrypt(" [>] Gamemanager: ") << GameVars::gamemanager << std::endl;
	std::cout << skCrypt(" [>] Entitylist: ") << GameVars::entitylist << std::endl;
	std::cout << skCrypt(" [>] Entitycount: ") << GameVars::entitycount << std::endl;
	SetConsoleTextAttribute(hConsole, 10);
	std::cout << skCrypt(" [+] Injected!") << std::endl;
	Beep(700, 500);
	Sleep(3000);
	//ShowWindow(GetConsoleWindow(), SW_HIDE);
	// if you need help dm OverHead#1752
	while (true)
	{
		LoopESP();
		Sleep(10);
	}
}