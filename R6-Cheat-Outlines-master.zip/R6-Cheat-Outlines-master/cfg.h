#pragma once
#pragma once

namespace CFG
{
	//	Visuals
	bool b_EspGlow = true;
	bool b_GadgetGlow = true;

	//	Aimbot
	bool b_Aimbot = false;

	//	Weapon
	bool b_NoRecoil = false;
	bool b_NoSpread = false;

	bool b_Loop = false;
}