#pragma once
#pragma once
#include <Windows.h>
#pragma warning(disable : 4996)

namespace Utilities
{
	void Kill()
	{
		Beep(300, 500);
		exit(0);
	}

	const std::string CurrentDateTime()
	{
		time_t     now = time(0);
		struct tm  tstruct;
		char       buf[80];
		tstruct = *localtime(&now);
		strftime(buf, sizeof(buf), "%m/%d/%y %X", &tstruct);

		return buf;
	}

	std::string tm_to_readable_time2(tm ctx)
	{
		char buffer[80];

		strftime(buffer, sizeof(buffer), "%m/%d/%y %H:%M:%S", &ctx);

		return std::string(buffer);
	}

	std::string tm_to_readable_time(tm ctx)
	{
		char buffer[80];

		strftime(buffer, sizeof(buffer), "%a %m/%d/%y %H:%M:%S %Z", &ctx);

		return std::string(buffer);
	}

	static std::time_t string_to_timet(std::string timestamp)
	{
		auto cv = strtol(timestamp.c_str(), NULL, 10); // long

		return (time_t)cv;
	}

	static std::tm timet_to_tm(time_t timestamp)
	{
		std::tm context;

		localtime_s(&context, &timestamp);

		return context;
	}

	BOOL IsProcessRunning(DWORD pid)
	{
		HANDLE process = OpenProcess(SYNCHRONIZE, FALSE, pid);
		DWORD ret = WaitForSingleObject(process, 0);
		CloseHandle(process);
		return ret == WAIT_TIMEOUT;
	}

	std::string getexepath()
	{
		char result[MAX_PATH];
		return std::string(result, GetModuleFileName(NULL, result, MAX_PATH));
	}

	void CheckSiegePath()
	{
		std::string currentPath = Utilities::getexepath();
		std::string siegeName = "Tom Clancy's Rainbow Six Siege";
		if (!strstr(currentPath.c_str(), siegeName.c_str()))
		{
			MessageBox(NULL, "Place this file in the \"Tom Clancy's Rainbow Six Siege\" installation folder and then run the game!", "ERROR", MB_OK | MB_ICONERROR);
			exit(0);
		}
	}
}