#pragma once
#pragma once
#include "hexrays.h"
#include <cstdint>
#include <memory.h>

// updated
namespace offsets
{
	std::uint64_t getGameManager() //ok
	{
		uintptr_t game_manager_addr = memory.base + 0x8599880;
		uintptr_t game_manager_val = memory.read<uintptr_t>(game_manager_addr);
		uintptr_t table_addr = memory.base + 0x66560A0;

		unsigned __int64 v0; // rbx
		unsigned __int64 v1; // r9
		int v2; // eax
		unsigned __int64 v3; // rdi

		v0 = (((unsigned __int64)(unsigned __int8)(((game_manager_val + 127) ^ 0x70) + 88) << 48) | ((unsigned __int64)(((((_DWORD)game_manager_val + 1113569663) ^ 0xFE50B370) - 852974248) & 0xFF0000) << 40)) >> 48;
		v1 = (unsigned __int64)game_manager_addr >> 3;
		v2 = memory.read<uint32_t>(table_addr
			+ (((1326381012 * (_DWORD)v0 - 1792956912 * (unsigned int)((unsigned __int64)game_manager_addr >> 3)) >> 22) & 0xFFFFFFFC));
		v3 = (((((game_manager_val - 0x436A461DBDA04681i64) ^ 0x9C01EE9AFE50B370ui64) + 0x1FD9C6A9CD28A558i64) >> 24) & 0xFF00 | ((unsigned __int64)((unsigned __int16)(((game_manager_val - 18049) ^ 0xB370) - 23208) & 0xFF00) << 24) | (((((_DWORD)game_manager_val + 1113569663) ^ 0xFE50B370) - 852974248) >> 24) | (((game_manager_val - 0x436A461DBDA04681i64) ^ 0x9C01EE9AFE50B370ui64) + 0x1FD9C6A9CD28A558i64) & 0xFF0000000000i64 | ((((game_manager_val - 0x436A461DBDA04681i64) ^ 0x9C01EE9AFE50B370ui64) + 0x1FD9C6A9CD28A558i64) >> 32) & 0xFFFF0000) ^ (BYTE2(v2) | ((unsigned __int64)BYTE1(v2) << 8) | ((unsigned __int64)BYTE2(v2) << 16) | ((unsigned __int64)BYTE2(v2) << 24) | ((unsigned __int64)BYTE1(v2) << 32) | ((unsigned __int64)(unsigned __int8)v2 << 40));

		return v3;
	}

	std::uint64_t getlocalplayer()
	{

	}

	std::uint32_t roundstate()
	{

	}

	static std::pair<uint64_t, uint32_t> entityManager(uint64_t game_manager) //ok
	{
		uint64_t entity_list = ((memory.read<uint64_t>(game_manager + 0x168) - 0x6780EA5BE5FD3C8Ai64) ^ 49i64) - 0x62392BCDD30A1391i64;
		uint64_t entity_count = (memory.read<uint64_t>(game_manager + 0x170) + 0x3D2FD58500E96DC3i64) - 0x50499CF0EF7A5375i64;
		entity_count = 22;

		//uint64_t entity_list = __ROL8__(__ROL8__(driver->read<uint64_t>(game_manager + 0x78), 11) - 67i64, 22);
		//uint64_t entity_count = __ROL8__(__ROL8__(driver->read<uint64_t>(game_manager + 0x80), 11) - 0x6990B7B688F881CCi64, 22);

		//uint64_t entity_list = __ROL8__(__ROL8__(driver->read<uint64_t>(game_manager + 0x58), 57) - 0x23269B20DCC5D822i64, 24);
		//uint64_t entity_count = __ROL8__(__ROL8__(driver->read<uint64_t>(game_manager + 0x60), 57) + 0x19ED3541631AE563i64, 24);

		uint32_t entity_count_32 = entity_count & 0x3FFFFFFF;
		return { entity_list, entity_count_32 };
	}

	std::uint64_t replicationinfo(uint64_t entity)
	{
		return __ROL8__(memory.read<uint64_t>(entity + 0x98) ^ 0xE83922DA7E8D36F0ui64, 32) + 0x546A7F6A667D697Ai64;
	}

	std::uint64_t get_team_id(uint64_t replication)
	{
		auto v5 = __ROL8__(memory.read<std::uint64_t>(replication + 0xA8) ^ 0xEBFCD9CB90396443ui64, 51) - 113i64;
		if (v5)
			return __ROL4__(memory.read<std::uint32_t >(v5 + 0xA8) + 0x5C16BA75, 26) ^ 0x486AD9E8;
	}

	uint64_t WeaponManager(uint64_t actor)
	{
		auto entry = ((memory.read<uint64_t>(actor + 0x70) - 77i64) ^ 0x7F) - 0x17952C0716F342A2i64;
		return (__ROL8__(memory.read<uint64_t>(entry + 0x268) ^ 0x3D9D63846A29925Ci64, 36) - 41i64);
	}

	namespace player {
		std::uint64_t pawn(std::uint64_t entity) //ok
		{
			return __ROL8__(memory.read<uint64_t>(entity + 0x38i64) - 0x41i64, 41) - 99i64;
		}

		std::uint64_t actor(std::uint64_t pawn) //ok
		{
			return (__ROL8__(memory.read<uint64_t>(pawn + 0x18), 0x37) ^ 4i64) - 0x404ED53CE2405926i64;
		}

		inline std::uint64_t outlineComponent(std::uint64_t actor) //ok
		{
			return __ROL8__(memory.read<uint64_t>(actor + 0x1C8) ^ 0x833548EB5765ADFFui64, 31);
		}

		inline void outlines(std::uint64_t actor) {
			/*uint64_t outlineComp = outlineComponent(actor);
			uint64_t outlineState = memory.read<std::uint64_t>(outlineComp + 0xB0);
			if (outlineState != 0 && outlineState != 0x20748000000300ee)
				memory.write(outlineComp + 0xB0, 0x20748000000300ee);*/

			auto glow_val = memory.read<uint32_t>(outlineComponent(actor) + 0x68);
			glow_val |= (uint32_t)1ul << 29;
			memory.write<std::uint32_t>(outlineComponent(actor) + 0x68, glow_val);
		}

		inline void removeOutlines(std::uint64_t actor) {
			uint64_t outlineComp = outlineComponent(actor);
			uint64_t outlineState = memory.read<std::uint64_t>(outlineComp + 0xB0);
			memory.write<std::uintptr_t>(outlineComp + 0xB0, 0x00748000000300ee);
		}
	}

	namespace game { //NOT WORKING
		inline std::uint64_t outline_component(std::uint64_t actor) {
			std::uintptr_t component = memory.read<std::uintptr_t>(actor + 0x1C8);
			component = __ROL8__(component, 0x15);
			component ^= 0x9B5BA4443C1749BC;
			component += 0x3EEF4D1F133B1433;
			return component;
		}

		inline void outlinesGadgets(std::uint64_t actor) {
			if (memory.read<std::uintptr_t>(outline_component(actor) + 0xB0) == 0x00744000)
				memory.write<std::uintptr_t>(outline_component(actor) + 0xB0, 0x20744000);
		}

		inline void removeOutlinesGadgets(std::uint64_t actor) {
			if (memory.read<std::uintptr_t>(outline_component(actor) + 0xB0) == 0x20744000)
				memory.write<std::uintptr_t>(outline_component(actor) + 0xB0, 0x00744000);
		}
	}
}